import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AutenticacionService {
  
  private url = 'http://localhost:8000/api';

  /**
   * Constructor de la clase AutenticacionService
   * @param http HttpClient, para realizar el llamado al backend mediante HTTP
   */
  constructor(private http:HttpClient) { }

  /**
   * Metodo POST que se encarga de enviar los datos de inicio de sesion al backend
   * y recibir la respuesta del servidor
   * @param usuario string para enviar al backend
   * @param contrasenia string para enviar al backend
   * @param tipoUsuario string para enviar al backend
   * @returns el usuario si lo encontro
   */
   login(usuario: string, contrasenia: string, tipoUsuario: string): Observable<any> {
    return this.http.post(`${this.url}/login`, { usuario, contrasenia, tipoUsuario });
  }
}
