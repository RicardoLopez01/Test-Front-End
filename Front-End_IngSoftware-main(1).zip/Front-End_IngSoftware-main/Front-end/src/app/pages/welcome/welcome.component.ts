import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-welcome',
  standalone: true,
  imports: [],
  templateUrl: './welcome.component.html',
  styleUrl: './welcome.component.css'
})
export class WelcomeComponent implements OnInit {
  ngOnInit(): void {
    this.inicializar();
  }

  //metodo que se encarga de inicializar la barra de navegacion
  inicializar(){
    this.opcionActual('2');
  }

  //metodo que se encarga de cambiar el color de la barra de navegacion segun la opcion seleccionada
  opcionActual(opcion: string): void {

    //reseteamos estilos de todas las opciones
    for (let i = 1; i <= 3; i++) {
      const elementoReseteado = document.getElementById('nav'+i) as HTMLElement;
      if (elementoReseteado) {
        elementoReseteado.style.backgroundColor = "";
        elementoReseteado.style.color = "";
        elementoReseteado.style.borderRadius = "";
      }
    }
  
    //aplicamos estilos a la opción seleccionada
    let opcionInt: number = parseInt(opcion);
    const elementoSeleccionado = document.getElementById('nav'+opcion) as HTMLElement;
    elementoSeleccionado.style.backgroundColor = "#4fc3b7";
    elementoSeleccionado.style.color = "white";
    elementoSeleccionado.style.borderRadius = "13px";

    const pagInfoCentro = document.getElementById('pagInfoCentro') as HTMLElement;
    const pagEquipoMedico = document.getElementById('pagEquipoMedico') as HTMLElement;
    switch (opcionInt){
      case 1:
        pagInfoCentro.style.display = 'none';
        pagEquipoMedico.style.display = 'block';
        break;
      case 2:
        pagInfoCentro.style.display = 'block';
        pagEquipoMedico.style.display = 'none';
        break;
      case 3:
        pagInfoCentro.style.display = 'none';
        pagEquipoMedico.style.display = 'none';
        break
    }
  }
}
