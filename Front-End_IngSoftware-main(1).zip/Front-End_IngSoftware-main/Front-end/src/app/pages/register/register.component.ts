import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [],
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})

//TODO: Agregar funciones para conectarse al backend y validar el registro de un nuevo usuario
export class RegisterComponent {

  /**
   * Constructor de la clase RegisterComponent
   * @param router Router para poder navegar por las paginas
   */
  constructor(private router: Router) {}

  /**
   * Metodo que se encarga de navegar por las paginas
   * @param direccion string que almacena la direccion de la pagina a navegar
   * @returns si no se pudo navegar a la direccion
   */
  confirmarInicio(direccion: string) {

    //se obtienen los elementos del formulario de registro del nuevo usuario
    const nombreRegistroImput = document.getElementById('nombreRegistro') as HTMLInputElement;
    const apellidoRegistroImput = document.getElementById('apellidoRegistro') as HTMLInputElement;
    const rutRegistroImput = document.getElementById('rutRegistro') as HTMLInputElement;
    const telefonoRegistroImput = document.getElementById('telefonoRegistro') as HTMLInputElement;
    const emailRegistroImput = document.getElementById('emailRegistro') as HTMLInputElement;
    const contraseniaRegistroImput = document.getElementById('contraseniaRegistro') as HTMLInputElement;

    const mensajeNombreImput = document.getElementById('mensajeNombre') as HTMLInputElement;
    const mensajeApellidoImput = document.getElementById('mensajeApellido') as HTMLInputElement;
    const mensajeRutImput = document.getElementById('mensajeRut') as HTMLInputElement;
    const mensajeTelefonoImput = document.getElementById('mensajeTelefono') as HTMLInputElement;
    const mensajeEmailImput = document.getElementById('mensajeCorreo') as HTMLInputElement;
    const mensajeContraseniaImput = document.getElementById('mensajeContrasenia') as HTMLInputElement;

    //se valida que el campo del nombre
    if (nombreRegistroImput.value === null || nombreRegistroImput.value.length < 3) {
      mensajeNombreImput.style.display = "flex";
      nombreRegistroImput.style.border = "2px solid red";

    }

    //se valida que el campo del apellido
    if (apellidoRegistroImput.value === null || apellidoRegistroImput.value.length < 3) {
      mensajeApellidoImput.style.display = "flex";
      apellidoRegistroImput.style.border = "2px solid red";

    }

    //se valida que el campo del rut
    if (rutRegistroImput.value === null || !this.validarRut(rutRegistroImput.value)) {
      mensajeRutImput.style.display = "flex";
      rutRegistroImput.style.border = "2px solid red";

    }

    //se valida que el campo del telefono
    if (telefonoRegistroImput.value === null || telefonoRegistroImput.value.length < 12) {
      mensajeTelefonoImput.style.display = "flex";
      telefonoRegistroImput.style.border = "2px solid red";

    }

    //se valida que el campo del email
    if (emailRegistroImput.value === null || this.validarCorreo(emailRegistroImput.value) === false) {
      mensajeEmailImput.style.display = "flex";
      emailRegistroImput.style.border = "2px solid red";

    }

    //se valida que el campo de la contrasenia
    if (contraseniaRegistroImput.value === null || contraseniaRegistroImput.value.length < 8) {
      mensajeContraseniaImput.style.display = "flex";
      contraseniaRegistroImput.style.border = "2px solid red";
    }

    //si ingreso a alguna validacion se retorna
    if((nombreRegistroImput.value === null || nombreRegistroImput.value.length < 3) ||
    (apellidoRegistroImput.value === null || apellidoRegistroImput.value.length < 3) ||
    (rutRegistroImput.value === null || !this.validarRut(rutRegistroImput.value)) ||
    (telefonoRegistroImput.value === null) ||
    (emailRegistroImput.value === null) ||
    (contraseniaRegistroImput.value === null || contraseniaRegistroImput.value.length < 8) ||
    this.validarCorreo(emailRegistroImput.value) === false) {
      return;
    }

    this.router.navigate([direccion]);
  }

  /**
   * Valida el correo electronico ingresado por el usuario
   * @param email string que almacena el correo
   * @returns true si el correo fue valido
   */
  validarCorreo(email: string): boolean {
    const regex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.(edu|org|gov|com)$/;
    console.log('el correo entro al metodo de validacion');
    return regex.test(email);
    
  }

/**
 * Valida si un string es un RUT chileno válido
 * @param rut String con el RUT a validar (puede contener puntos y guión)
 * @returns boolean True si el RUT es válido, False en caso contrario
 */
  validarRut(rut: string): boolean {
  // Verificar que el rut no esté vacío
  if (!rut || rut.trim() === '') {
    return false;
  }

  // Eliminar puntos y guión para normalizar el formato
  const rutLimpio = rut.replace(/[.-]/g, '');
  
  // Verificar que el rut tenga al menos 2 caracteres (1 dígito + dígito verificador)
  if (rutLimpio.length < 2) {
    return false;
  }
  
  // Separar el cuerpo y el dígito verificador
  const cuerpo = rutLimpio.slice(0, -1);
  const digitoVerificador = rutLimpio.slice(-1).toUpperCase();
  
  // Verificar que el cuerpo contenga solo dígitos
  if (!/^\d+$/.test(cuerpo)) {
    return false;
  }
  
  // Calcular el dígito verificador esperado
  const digitoEsperado = this.calcularDigitoVerificador(cuerpo);
  
  // Comparar el dígito verificador calculado con el proporcionado
  return digitoVerificador === digitoEsperado;
}

/**
 * Calcula el dígito verificador de un RUT
 * @param cuerpoRut String con el cuerpo del RUT (sin dígito verificador)
 * @returns string Dígito verificador calculado
 */
  calcularDigitoVerificador(cuerpoRut: string): string {
  // Convertir a número y aplicar el algoritmo de módulo 11
  let suma = 0;
  let multiplicador = 2;
  
  // Recorrer el cuerpo del RUT de derecha a izquierda
  for (let i = cuerpoRut.length - 1; i >= 0; i--) {
    suma += parseInt(cuerpoRut.charAt(i)) * multiplicador;
    multiplicador = multiplicador === 7 ? 2 : multiplicador + 1;
  }
  
  // Calcular el dígito verificador
  const resto = suma % 11;
  const resultado = 11 - resto;
  
  // Determinar el dígito verificador según las reglas
  if (resultado === 11) {
    return '0';
  } else if (resultado === 10) {
    return 'K';
  } else {
    return resultado.toString();
  }
}
}

