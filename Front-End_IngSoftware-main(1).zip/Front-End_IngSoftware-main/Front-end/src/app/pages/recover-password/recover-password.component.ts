import { Component } from '@angular/core';

@Component({
  selector: 'app-recover-password',
  standalone: true,
  imports: [],
  templateUrl: './recover-password.component.html',
  styleUrl: './recover-password.component.css'
})

//TODO: Agregar funciones para conectarse al backend y validar el envio del codigo al correo
export class RecoverPasswordComponent {

  //metodo que se encarga de confirmar el envio del correo de recuperacion
  confirmacionCodigoEnviado(){

    //se obtienen los elementos del formulario de recuperacion de contrasenia (email y mensaje)
    const emailRecuperacion = document.getElementById("recoveryEmail") as HTMLInputElement;
    const mensaje = document.getElementById("mensaje") as HTMLInputElement;
    const mensajeErroneo = document.getElementById("mensajeErroneo") as HTMLInputElement;
    

    //se valida que el campo de email no este vacio
    if (!(emailRecuperacion.value === "" || emailRecuperacion.value === null) && this.validarCorreo(emailRecuperacion.value) === true) {

      if(emailRecuperacion.value === 'brucemunizaga85@gmail.com' ){
        mensaje.style.display = "block";
        mensajeErroneo.style.display = "none";
      }
      else{
        mensajeErroneo.style.display = "block";
        mensaje.style.display = "none";
      }

      //si anteriormente el campo de email estaba en rojo, se le quita el borde rojo y se le pone el borde normal
      if (emailRecuperacion.style.border = "solid red") {
        emailRecuperacion.removeAttribute("placeholder");
        emailRecuperacion.style.border = "1px solid #ddd";
      }

      //se vuelve a setear el valor del campo de email a vacio para que el usuario pueda ingresar otro correo
      emailRecuperacion.value = "";
      return;

    }else if (this.validarCorreo(emailRecuperacion.value) === false){

      emailRecuperacion.value = "";

      emailRecuperacion.placeholder = "Por favor ingrese un correo valido";
      emailRecuperacion.style.border = "2px solid red";
      return;

    }

    
    
  }

      //metodo que se encarga de validar el correo electronico ingresado por el usuario
      validarCorreo(email: string): boolean {
        const regex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.(edu|org|gov|com)$/;
        console.log('el correo entro al metodo de validacion');
        return regex.test(email);
        
      }
}