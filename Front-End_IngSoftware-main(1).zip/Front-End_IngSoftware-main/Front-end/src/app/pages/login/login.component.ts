import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { AutenticacionService } from '../../service/autenticacion/autenticacion.service';
import { HttpClient, HttpClientModule } from '@angular/common/http';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [
    FormsModule,
    HttpClientModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})

//TODO: Validar si la conexión al backend es correcta y si el usuario existe y la contraseña es correcta
export class LoginComponent {

  tipoUsuario: string = "";

  /**
   * Constructor de LoginComponent
   * @param router Router para navegar por las paginas
   */
  constructor(private router: Router, /*private autenticacion: AutenticacionService*/) {} //TODO: descomentar cuando se trate de conectar al backend

  /**
   * Metodo que se ejecuta al cargar la pagina 
   */
  ngOnInit(): void {
    this.inicializar();
  }

  /**
   * Metodo que se encarga de inicializar la barra de navegacion
   */
  inicializar(){
    const elementoInicial = document.getElementById('nav1') as HTMLElement;
    elementoInicial.style.backgroundColor = "#4fc3b7";
    elementoInicial.style.color = "white";
    elementoInicial.style.borderRadius = "7px";
  }

  /**
   * Cambia el color de la barra de navegacion segun la opcion seleccionada en la barra de navegacion
   * @param opcion string que indica la opcion escogida
   */
  opcionActual(opcion: string): void {

    //reseteamos estilos de todas las opciones
    for (let i = 1; i <= 3; i++) {
      const elementoReseteado = document.getElementById('nav'+i) as HTMLElement;
      if (elementoReseteado) {
        elementoReseteado.style.backgroundColor = "";
        elementoReseteado.style.color = "";
        elementoReseteado.style.borderRadius = "";
      }
    }
  
    //aplicamos estilos a la opción seleccionada
    const elementoSeleccionado = document.getElementById('nav'+opcion) as HTMLElement;
    const portal = document.getElementById('portal') as HTMLElement;
    elementoSeleccionado.style.backgroundColor = "#4fc3b7";
    elementoSeleccionado.style.color = "white";
    elementoSeleccionado.style.borderRadius = "7px";

    switch(opcion) {
      case '1':
        portal.textContent = "Portal Usuario";
        this.tipoUsuario = "usuario";
        console.log(this.tipoUsuario);
        break;
      case '2':
        portal.textContent = "Portal Médico";
        this.tipoUsuario = "medico";
        console.log(this.tipoUsuario);
        break;
      case '3':
        portal.textContent = "Portal Administrador";
        this.tipoUsuario = "administrador";
        console.log(this.tipoUsuario);
        break;
    }
    
  }

  /**
   * Valida si el correo electronico ingresado por el usuario tiene el formato correcto
   * @param email string, para validar
   * @returns true, si el correo tiene el formato valido
   */
  validarCorreo(email: string): boolean {
    const regex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.(edu|ucn|alumnos.ucn.cl|org|gob||com|cl)$/;
    return regex.test(email);
  }

  /**
   * Navega por las paginas
   * @param direccion string que almacena la direccion de la pagina a navegar
   * @returns si no se pudo navegar a la direccion
   */
  confirmarInicioUsuario(direccion: string) {

    //se obtienen los elementos del formulario de inicio de sesion (email, contrasenia y mensaje)
    const emailImput = document.getElementById('email') as HTMLInputElement;
    const passwordImput = document.getElementById('contrasenia') as HTMLInputElement;
    const mensajeErrorEmail = document.getElementById("mensajeErrorEmail") as HTMLInputElement;
    const mensajeErrorContrasenia = document.getElementById("mensajeErrorContrasenia") as HTMLInputElement;

    //se valida que el campo de email no este vacio
    if (emailImput.value === '' || emailImput.value === null|| this.validarCorreo(emailImput.value) === false) {
      mensajeErrorEmail.textContent = "Ingrese un correo valido";
      emailImput.style.border = "2px solid red";
      mensajeErrorEmail.style.display = "block";
    }

    //se valida que el campo de contrasenia no este vacia
    if (passwordImput.value === '' || passwordImput.value === null) {
      mensajeErrorContrasenia.textContent = "Ingrese una contraseña valida";
      passwordImput.style.border = "2px solid red";
      mensajeErrorContrasenia.style.display = "block";
    }

    //si estos campos estan vacios se no navega a la ruta que se le paso por parametro
    if((emailImput.value === '' || emailImput.value === null) || (passwordImput.value === '' || passwordImput.value === null || this.validarCorreo(emailImput.value) === false)) {
      return;
    }

    //TODO: Probar con el backend si el usuario existe y la contraseña es correcta
    /*this.autenticacion.login(emailImput.value, passwordImput.value, this.tipoUsuario).subscribe(
      response => {
        console.log('Inicio de sesión exitoso:', response);
        this.router.navigate([direccion]);
      });
    */
  }
}
